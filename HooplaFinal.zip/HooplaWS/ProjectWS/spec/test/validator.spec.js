const validator=require('../../src/utilities/validator')

describe("Email id validator",()=>{
    it("for invalid email id it should throw error",()=>{
        try{
            validator.validateid("test.com")
        }catch(e){
            expect(true).toBeTruthy();
        }
    })
    it("for valid email id it should not throw error",()=>{
        try{
            validator.validateid("sruthi@infy.com")
            expect(true).toBeTruthy();
        }catch(e){

        }
    })
})
describe("Password validator",()=>{
    it("for invalid password id it should throw error",()=>{
        try{
            validator.validatePassword("mountEverest")
        }catch(e){
            expect(true).toBeTruthy();
        }
    })
    it("for valid password it should not throw error",()=>{
        try{
            validator.validatePassword("Stefan$9ru7e")
            expect(true).toBeTruthy();
        }catch(e){
            
        }
    })
})