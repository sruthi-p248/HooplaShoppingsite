class Customer {
    constructor(obj) {
        this.emailId=obj.emailId,
        this.password=obj.password
    }
}

module.exports = Customer;