// import { AppPage } from './app.po';
import { browser, by , element} from "protractor";

describe("workspace-project App", () => {
  it("On load it should navigate to dashboard page", () => {
    browser.get("http://localhost:4200/");
    browser.sleep(2000);
    expect(browser.getCurrentUrl()).toContain("view-products");
  });
  it("filling up login form", () => {
    const email = element(by.name("username"));
    const pass = element(by.name("password"));
    const but = element(by.name("loginButton"));

    email.sendKeys("sruthi@infy.com");
    browser.sleep(2000);
    pass.sendKeys("Stefan$9ru7e");
    browser.sleep(2000);
    but.click();
    browser.sleep(2000);
    expect(browser.getCurrentUrl()).toContain("view-products/sruthi@infy.com");
  });
  it(" when view orders button is clicked it should navigate to orders page", () => {
    const but = element(by.name("orders"));
    but.click();
    browser.sleep(2000);
    expect(browser.getCurrentUrl()).toContain("view-orders");

  });
  it("when logout is clicked it should navigate to home page", () => {
    const but = element(by.name("logoutButton"));
    but.click();
    browser.sleep(2000);
    expect(browser.getCurrentUrl()).toContain("/view-orders/sruthi@infy.com");
  });

});
