import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

import { HttpClientModule } from "@angular/common/http";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {MatBadgeModule, MatButtonModule, MatCardModule, MatFormFieldModule } from "@angular/material";
import { MatIconModule, MatInputModule, MatSnackBarModule, MatToolbarModule} from "@angular/material";
import { MatMenuModule } from "@angular/material";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { LoginComponent } from "./login/login.component";
import { ProductComponent } from "./product/product.component";
import { ViewOrdersComponent } from "./view-orders/view-orders.component";
import { ViewProductsComponent } from "./view-products/view-products.component";

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ViewProductsComponent,
    ViewOrdersComponent,
    ProductComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    MatToolbarModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ReactiveFormsModule,
     MatButtonModule,
     MatFormFieldModule,
     MatInputModule,
     MatCardModule,
     MatBadgeModule,
     MatSnackBarModule,
     MatIconModule, MatMenuModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule { }
