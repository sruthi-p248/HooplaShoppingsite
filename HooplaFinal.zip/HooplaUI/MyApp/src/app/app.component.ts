import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"],
})
export class AppComponent implements OnInit {
  public title = "Project";
  public login: boolean;
  public emailId: string;
  constructor(private route: Router) {}
  public ngOnInit() {
    this.login = true;
  }
  public log(email) {
    this.emailId = email;
    this.login = false;
    this.route.navigate(["/view-products", this.emailId]);
  }
  public logout() {
    this.emailId = "";
    this.login = true;
  }
  public view() {
    this.route.navigate(["/view-orders", this.emailId]);
  }
}
