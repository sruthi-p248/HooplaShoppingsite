import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Customer } from "./../shared/customer";
import { Order } from "./../shared/order";

@Injectable({
  providedIn: "root",
})
export class LoginServiceService {

  constructor( private http: HttpClient ) {  }

  public login(data): Observable<Customer> {
    return this.http.post<Customer>("http://localhost:3000/login", data);
  }

  public cust(data, prodId): Observable<any> {
    return this.http.put<any>("http://localhost:3000/getcustomer/" + data, prodId);
  }

  public order(emailId): Observable<Order[]> {
    return this.http.get<Order[]>("http://localhost:3000/getorders/" + emailId);
  }
}
