import { Component, EventEmitter , OnInit, Output } from "@angular/core";
import { FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { LoginServiceService } from "./login-service.service";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  public loginForm: FormGroup;
  public emailId: string;
  public errorMessage: string;
  @Output()
  public email: EventEmitter<string> = new EventEmitter<string>();

  constructor(private fb: FormBuilder, private serv: LoginServiceService) { }

  public ngOnInit() {
    this.loginForm = this.fb.group({
      emailId: ["", [Validators.required, Validators.email]],
      password: ["", [Validators.required, this.validatePassword]],
    });
  }
  public onSubmit() {
    this.errorMessage = "";
    this.serv.login(this.loginForm.value).subscribe((success) => {
      this.emailId = success.emailId;
      // console.log(this.emailId);
      this.email.emit(this.emailId);

    }, (err) => {this.errorMessage = err.error.message; });
  }
  public validatePassword(password: FormControl) {
    const regEx = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$\%\^\&\*]).{7,20}/;
    return regEx.test(password.value) ? null : {passwordError: {message: "invalid password"}};
  }

}
