export class Seller {
        public sId: string;
        public pDiscount: number;
        public pQuantity: number;
        public pShippingCharges: number;
}
