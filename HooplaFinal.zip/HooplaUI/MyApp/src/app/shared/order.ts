export class Order {
    public orderId: number;
    public prodId: [string];
    public price: number;
    public date: Date;
}
