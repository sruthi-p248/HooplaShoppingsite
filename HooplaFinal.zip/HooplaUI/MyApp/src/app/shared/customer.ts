export class Customer {
    public emailId: string;
    public password: string;
}
