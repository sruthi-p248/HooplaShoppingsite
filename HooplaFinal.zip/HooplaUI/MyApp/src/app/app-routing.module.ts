import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { LoginComponent } from "./login/login.component";
import { ProductComponent } from "./product/product.component";
import { ViewOrdersComponent } from "./view-orders/view-orders.component";
import { ViewProductsComponent } from "./view-products/view-products.component";

const routes: Routes = [
  {path: "", redirectTo: "/view-products", pathMatch: "full"},
  {path: "login", component: LoginComponent},
  {path: "view-products", component: ViewProductsComponent},
  {path: "view-products/:emailId", component: ViewProductsComponent},
  {path: "view-orders/:emailId", component: ViewOrdersComponent},
  {path: "product/:emailId/:prodId", component: ProductComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
