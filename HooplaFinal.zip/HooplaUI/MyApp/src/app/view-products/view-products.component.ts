import { Component, OnInit } from "@angular/core";
import { MatSnackBar } from "@angular/material/snack-bar";
import { ActivatedRoute, Router } from "@angular/router";
import { LoginServiceService } from "../login/login-service.service";
import { Order } from "./../shared/order";
import { ViewProductServiceService } from "./view-product-service.service";

@Component({
  selector: "app-view-products",
  templateUrl: "./view-products.component.html",
  styleUrls: ["./view-products.component.css"],
})
export class ViewProductsComponent implements OnInit {
  public errorMessage: string;
  public productsAll;
  public products;
  public search;
  public emailId;
  public successMessage;
  public filter;
  public categories = ["Furniture", "Electronics", "Clothing", "Shoes"];
  public discount = [];
  public data;
  constructor(private serv: ViewProductServiceService,
              private route: ActivatedRoute,
              private custServ: LoginServiceService,
              private router: Router, private snack: MatSnackBar ) { }
  public ngOnInit() {
    this.errorMessage = "";
    this.filter = "";
    this.data = true;
    this.serv.getAllProducts().subscribe((success) => {
      this.productsAll = success;
      this.categ();
    }, (err) => {
      this.errorMessage = err.error.message;
      this.snack.open(this.errorMessage, "", {
        duration: 1000,
        panelClass: ["red-snackbar"],
      });
    });
    this.route.params.subscribe((s) => {this.emailId = s.emailId; });
  }
  public display(filter) {
    this.filter = filter;
    this.data = false;
    this.products = this.productsAll.filter((ele) => {
      if (ele.pCategory === filter) {
        return true;
      }
    });
  }
  public show() {
    this.data = false;
    this.products = this.productsAll.filter((ele) => {
      if (ele.pName.toUpperCase().match(this.search.toUpperCase())) {
        return true;
      }
    });
  }
  public prodDesc(prodId) {
    this.router.navigate(["/product/" + this.emailId, +prodId]);
  }
  public buy(prodId) {
    this.successMessage = "";
    this.errorMessage = "";
    const ord = new Order();
    const dt = new Date();
    ord.date = dt;
    this.productsAll.forEach((e) => {
      if (e.id === prodId) {
        ord.price = e.price * (1 - e.pSeller[0].pDiscount);
      }
    });
    ord.prodId = prodId;
    this.custServ.cust(this.emailId, ord).subscribe((s) => {
      this.successMessage = s.message;
      this.snack.open(this.successMessage, "", {
        duration: 1000,
        panelClass: ["green-snackbar"],
      });
    }, (err) => {
      this.errorMessage = err.error.message;
      this.snack.open(this.errorMessage, "", {
        duration: 1000,
        panelClass: ["red-snackbar"],
      });
    });
  }
  public categ() {
    this.categories.forEach((cat) => {
      const disc = [];
      this.productsAll.forEach((prod) => {
        if (prod.pCategory === cat) {
          disc.push(prod.pSeller[0].pDiscount);
        }
      });
      this.discount.push((disc.sort()[(disc.length - 1)]) * 100);
    });
  }
  public snackBar() {
    this.snack.open("You will be notified", "", {duration: 1000, panelClass: ["green-snackbar"]});
  }

}
