import {OverlayContainer} from "@angular/cdk/overlay";
import {HttpClientTestingModule} from "@angular/common/http/testing";
import {CUSTOM_ELEMENTS_SCHEMA} from "@angular/core";
import { async, ComponentFixture, inject, TestBed } from "@angular/core/testing";
// import{inject} from "@angular/core";
import {FormsModule} from "@angular/forms";
import {MatSnackBar, MatSnackBarModule} from "@angular/material";
import {NoopAnimationsModule} from "@angular/platform-browser/animations";
import {RouterTestingModule} from "@angular/router/testing";
import {ViewProductServiceService} from "./view-product-service.service";

import { ViewProductsComponent } from "./view-products.component";

describe("ViewProductsComponent", () => {
  let component: ViewProductsComponent;
  let fixture: ComponentFixture<ViewProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewProductsComponent ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA,
      ],
      imports: [FormsModule, HttpClientTestingModule, RouterTestingModule, MatSnackBarModule, NoopAnimationsModule],
      providers: [ViewProductServiceService],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewProductsComponent);
    component = fixture.componentInstance;
    // element: fixture.nativeElement;
    fixture.detectChanges();
  });
  beforeEach(inject([MatSnackBar, OverlayContainer], ( oc: OverlayContainer) => {

    // overlayContainer: oc;
    // overlayContainerElement: oc.getContainerElement();
  }));

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should give the particular category", () => {
    component.productsAll = [
      {
        id: "1001",
        pName: "Asus Zenfone Max Pro ",
        pDescription: "an economical phone by Asus",
        pRating: 3.5,
        pCategory: "Electronics",
        price: 14999,
        color: "Black",
        image: "Zenfone Max Pro M2.jpg",
        specification: "",
        dateFirstAvailable: "2012-09-17T00:00:00.000Z",
        dateLastAvailable: "2017-09-17T00:00:00.000Z",
        pSeller: [{
          sId: "Asus@Seller",
          pDiscount: 0.2,
          pQuantity: 661,
          pShippingCharges: 150,
        }],
      },
      {
        id: "1002",
        pName: "Redmi Note 6 Pro",
        pDescription: "an economical phone by Xiaomi",
        pRating: 4,
        pCategory: "Electronics",
        price: 13999,
        color: "Black",
        image: "Redmi note 6 Pro.jpg",
        specification: "",
        dateFirstAvailable: "2012-09-17T00:00:00.000Z",
        dateLastAvailable: "2017-09-17T00:00:00.000Z",
        pSeller: [{
          sId: "Xiaomi@Seller",
          pDiscount: 0.2,
          pQuantity: 665,
          pShippingCharges: 150,
        }],
      },
      {
        id: "1008",
        pName: "Adidas Running Men robust ",
        pDescription: "A pair of robust running shoes by adidas in combo",
        pRating: 4,
        pCategory: "Shoes",
        price: 3599,
        color: "Black",
        image: "adidas 1.jpg",
        specification: "",
        dateFirstAvailable: "2012-09-17T00:00:00.000Z",
        dateLastAvailable: "2017-09-17T00:00:00.000Z",
        pSeller: [{
          sId: "Adidas@Seller",
          pDiscount: 0.2,
          pQuantity: 666,
          pShippingCharges: 150,
        }],
      }, {
        id: "1020",
        pName: "UCB T-shirt",
        pDescription: "100 % pure cotton t shirt by UCB",
        pRating: 4.2,
        pCategory: "Clothing",
        price: 1900,
        color: "Blue",
        image: "UCB tshirt.jpg",
        specification: "",
        dateFirstAvailable: "2012-09-17T00:00:00.000Z",
        dateLastAvailable: "2017-09-17T00:00:00.000Z",
        pSeller: [{
          sId: "UCB@Seller",
          pDiscount: 0.2,
          pQuantity: 666,
          pShippingCharges: 150,
        }],
      },
    ];
    component.display("Clothing");
    expect(component.products).toEqual([{
      id: "1020",
        pName: "UCB T-shirt",
        pDescription: "100 % pure cotton t shirt by UCB",
        pRating: 4.2,
        pCategory: "Clothing",
        price: 1900,
        color: "Blue",
        image: "UCB tshirt.jpg",
        specification: "",
        dateFirstAvailable: "2012-09-17T00:00:00.000Z",
        dateLastAvailable: "2017-09-17T00:00:00.000Z",
        pSeller: [{
          sId: "UCB@Seller",
          pDiscount: 0.2,
          pQuantity: 666,
          pShippingCharges: 150,
        }],

    }]);
  });
  it("should give the products that match the search fields", () => {
    component.productsAll = [
      {
        id: "1001",
        pName: "Asus Zenfone Max Pro ",
        pDescription: "an economical phone by Asus",
        pRating: 3.5,
        pCategory: "Electronics",
        price: 14999,
        color: "Black",
        image: "Zenfone Max Pro M2.jpg",
        specification: "",
        dateFirstAvailable: "2012-09-17T00:00:00.000Z",
        dateLastAvailable: "2017-09-17T00:00:00.000Z",
        pSeller: [{
          sId: "Asus@Seller",
          pDiscount: 0.2,
          pQuantity: 661,
          pShippingCharges: 150,
        }],
      },
      {
        id: "1002",
        pName: "Redmi Note 6 Pro",
        pDescription: "an economical phone by Xiaomi",
        pRating: 4,
        pCategory: "Electronics",
        price: 13999,
        color: "Black",
        image: "Redmi note 6 Pro.jpg",
        specification: "",
        dateFirstAvailable: "2012-09-17T00:00:00.000Z",
        dateLastAvailable: "2017-09-17T00:00:00.000Z",
        pSeller: [{
          sId: "Xiaomi@Seller",
          pDiscount: 0.2,
          pQuantity: 665,
          pShippingCharges: 150,
        }],
      }, {
        id: "1008",
        pName: "Adidas Running Men robust ",
        pDescription: "A pair of robust running shoes by adidas in combo",
        pRating: 4,
        pCategory: "Shoes",
        price: 3599,
        color: "Black",
        image: "adidas 1.jpg",
        specification: "",
        dateFirstAvailable: "2012-09-17T00:00:00.000Z",
        dateLastAvailable: "2017-09-17T00:00:00.000Z",
        pSeller: [{
          sId: "Adidas@Seller",
          pDiscount: 0.2,
          pQuantity: 666,
          pShippingCharges: 150,
        }],
      }, {
        id: "1020",
        pName: "UCB T-shirt",
        pDescription: "100 % pure cotton t shirt by UCB",
        pRating: 4.2,
        pCategory: "Clothing",
        price: 1900,
        color: "Blue",
        image: "UCB tshirt.jpg",
        specification: "",
        dateFirstAvailable: "2012-09-17T00:00:00.000Z",
        dateLastAvailable: "2017-09-17T00:00:00.000Z",
        pSeller: [{
          sId: "UCB@Seller",
          pDiscount: 0.2,
          pQuantity: 666,
          pShippingCharges: 150,
        }],
      },
    ];
    component.search = "red";
    component.show();
    expect(component.products).toEqual([{
      id: "1002",
        pName: "Redmi Note 6 Pro",
        pDescription: "an economical phone by Xiaomi",
        pRating: 4,
        pCategory: "Electronics",
        price: 13999,
        color: "Black",
        image: "Redmi note 6 Pro.jpg",
        specification: "",
        dateFirstAvailable: "2012-09-17T00:00:00.000Z",
        dateLastAvailable: "2017-09-17T00:00:00.000Z",
        pSeller: [{
          sId: "Xiaomi@Seller",
          pDiscount: 0.2,
          pQuantity: 665,
          pShippingCharges: 150,
        }],
    }]);
  });
});
