import { TestBed } from "@angular/core/testing";

import { ViewProductServiceService } from "./view-product-service.service";
